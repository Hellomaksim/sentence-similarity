#!/usr/bin/env python 
# -*- coding:utf-8 -*-
__all__ = ["AttentionMechanism.py", "readfile", "model"]