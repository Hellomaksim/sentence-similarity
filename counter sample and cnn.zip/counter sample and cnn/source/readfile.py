#!/usr/bin/env python 
# -*- coding:utf-8 -*-

from AttentionMechanism import AttentionModel
import tensorflow as tf
w2v_dir = 'D:\dataset\glove.6B.50d.txt'
dictionary = {}
embeddings = []
english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '``', '\'\'']
with open(w2v_dir,'r',encoding="UTF8") as f:
    words = [x.rstrip().split(' ')[0] for x in f.readlines()]
    words = words[:10000]
    dictionary  = {word:(index) for index, word in enumerate(words)}
    del words
with open(w2v_dir,'r',encoding="UTF8") as f:
    vectors = [[float(y) for y in x.rstrip().split(' ')[1:]] for x in f.readlines()]
    vectors = vectors[:10000]
    embeddings = embeddings + vectors
    del vectors
class ReadDataset:
    def __init__(self, filename):
        f = open(filename, 'r',encoding="UTF8")
        self.dataset = f.readlines()
        f.close()
        self.dataset = self.dataset[1:]
        self.data_index = 0
        self.lines = len(self.dataset)
    def next_batch(self, batch):
        x = []
        y = []
        z = []
        sentencex = []
        sentencey = []
        for i in range(batch):
            data = self.dataset[self.data_index].strip().split('\t')
            sentencex.append(data[3])
            sentencey.append(data[4])
            Attention_Sen1_Matrix, Attention_Sen2_Matrix=AttentionModel().get_AttentionVector(data[1],data[2])
            l = float(data[0])
            x.append(Attention_Sen1_Matrix)
            y.append(Attention_Sen2_Matrix)
            z.append(l)
            self.data_index = (self.data_index + 1)%self.lines
        return x, y, z
