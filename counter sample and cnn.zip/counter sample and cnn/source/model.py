#!/usr/bin/env python 
# -*- coding:utf-8 -*-

import tensorflow as tf
import numpy as np
import pickle

class Flags:
    def __init__(self):
        self.train_dir = './dataset/msrp/msr_paraphrase_train.txt'
        self.test_dir = './dataset/msrp/counter_msr_paraphrase_test.txt'
        self.len_of_word_vector = 50
        self.len_of_sentence_vector =100 #used
        self.filter_para = 3
        self.batch_size = 128
        self.max_k = 3

def conv2d(x):
    W = tf.get_variable(name='weight', shape=[3, 3, 1, 8], dtype=tf.float32, initializer=tf.truncated_normal_initializer(mean=0, stddev=0.1))
    b = tf.get_variable(name='bias', shape=[8], dtype=tf.float32, initializer=tf.constant_initializer(0))
    conv = tf.nn.tanh(tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='VALID') + b)
    avg_pool1=tf.nn.max_pool(conv, [1,3,3,1],[1,2,2,1],padding='SAME',data_format='NHWC')
    W_1 = tf.get_variable(name='weight1', shape=[3, 3, 8, 8], dtype=tf.float32,initializer=tf.truncated_normal_initializer(mean=0, stddev=0.1))
    b_1 = tf.get_variable(name='bias1', shape=[8], dtype=tf.float32, initializer=tf.constant_initializer(0))
    conv_2 = tf.nn.tanh(tf.nn.conv2d(avg_pool1, W_1, strides=[1, 2, 2, 1], padding='VALID') + b_1)
    avg_pool2=tf.nn.max_pool(conv_2, [1,4,4,1], [1,5,3,1],padding="SAME", data_format='NHWC')
    a=tf.reduce_mean(avg_pool2, axis=3, keep_dims=False)
    sentence_vector=tf.reduce_sum(a,axis=1,keep_dims=False)
    return sentence_vector
